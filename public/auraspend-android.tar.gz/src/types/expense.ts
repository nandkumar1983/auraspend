export type TransactionType = 'debit' | 'credit';

export type CategoryId =
  | 'groceries'
  | 'dining'
  | 'shopping'
  | 'transport'
  | 'utilities'
  | 'housing'
  | 'entertainment'
  | 'health'
  | 'salary'
  | 'freelance'
  | 'investment'
  | 'transfer'
  | 'other';

export interface CategoryDef {
  id: CategoryId;
  name: string;
  icon: string;
  color: string;
  type: 'expense' | 'income' | 'both';
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: CategoryId;
  accountId: string;
  description: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  source: 'manual' | 'bank_sync' | 'sms_parser' | 'cloud_import';
  bankReference?: string;
  status: 'cleared' | 'pending';
  receiptNote?: string;
  tags?: string[];
}

export interface BankAccount {
  id: string;
  name: string;
  institution: string;
  accountNumber: string;
  type: 'checking' | 'savings' | 'credit' | 'cash';
  balance: number;
  availableLimit?: number; // for credit cards
  lastSyncedAt: string;
  syncStatus: 'connected' | 'syncing' | 'paused' | 'error';
  color: string;
  iconName: string;
  isAutoSyncEnabled: boolean;
}

export interface CategoryBudget {
  id: string;
  categoryId: CategoryId;
  monthlyLimit: number;
  alertThreshold: number; // e.g. 0.8 for 80%
}

export interface MonthlyReport {
  month: string; // YYYY-MM
  totalDebit: number;
  totalCredit: number;
  netSavings: number;
  savingsRate: number; // percentage
  categoryBreakdown: {
    categoryId: CategoryId;
    categoryName: string;
    color: string;
    total: number;
    count: number;
    percentage: number;
    budget?: number;
    isOverBudget: boolean;
  }[];
  topMerchants: {
    merchant: string;
    total: number;
    count: number;
  }[];
  dailySpendAverage: number;
  insights: string[];
}

export interface CloudSyncState {
  provider: 'google_drive' | 'cloud_storage' | 'local_secure';
  lastSyncedAt: string | null;
  autoSyncEnabled: boolean;
  syncIntervalHours: number;
  status: 'idle' | 'syncing' | 'success' | 'error';
  lastStatusMessage: string;
  storageUsedKb: number;
  backupHistory: CloudBackupRecord[];
}

export interface CloudBackupRecord {
  id: string;
  timestamp: string;
  recordCount: number;
  sizeKb: number;
  hash: string;
}
