/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AndroidFrame } from './components/AndroidFrame';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar, ActiveTab } from './components/BottomNavBar';
import { AddTransactionModal } from './components/AddTransactionModal';
import { SmsParserModal } from './components/SmsParserModal';
import { SecurityPinModal } from './components/SecurityPinModal';
import { InstallModal } from './components/InstallModal';
import { HomeView } from './views/HomeView';
import { TransactionsView } from './views/TransactionsView';
import { BudgetsView } from './views/BudgetsView';
import { ReportsView } from './views/ReportsView';
import { CloudSyncView } from './views/CloudSyncView';
import { AccountConfigView } from './views/AccountConfigView';
import { StorageService } from './services/storage';
import { BankSyncService } from './services/bankSync';
import { BankAccount, CategoryBudget, Transaction } from './types/expense';
import { CheckCircle2, AlertTriangle, ArrowDownRight, ArrowUpRight } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [transactions, setTransactions] = useState<Transaction[]>(() =>
    StorageService.getTransactions()
  );
  const [accounts, setAccounts] = useState<BankAccount[]>(() =>
    StorageService.getAccounts()
  );
  const [budgets, setBudgets] = useState<CategoryBudget[]>(() =>
    StorageService.getBudgets()
  );

  // Security Lock State
  const [savedPin, setSavedPin] = useState<string>(() => localStorage.getItem('auraspend_pin_code') || '1234');
  const [isPinEnabled, setIsPinEnabled] = useState<boolean>(() => localStorage.getItem('auraspend_pin_enabled') === 'true');
  const [isLocked, setIsLocked] = useState<boolean>(false);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSmsModalOpen, setIsSmsModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isFrameMode, setIsFrameMode] = useState(true);
  const [toastMessage, setToastMessage] = useState<{
    text: string;
    type: 'success' | 'alert' | 'info';
  } | null>(null);

  const showToast = (text: string, type: 'success' | 'alert' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const refreshAllData = () => {
    setTransactions(StorageService.getTransactions());
    setAccounts(StorageService.getAccounts());
    setBudgets(StorageService.getBudgets());
  };

  const handleTogglePin = (enabled: boolean) => {
    setIsPinEnabled(enabled);
    localStorage.setItem('auraspend_pin_enabled', enabled ? 'true' : 'false');
    showToast(enabled ? 'App Security PIN Lock Enabled.' : 'App Security PIN Lock Disabled.', 'info');
  };

  const handleUpdatePin = (newPin: string) => {
    setSavedPin(newPin);
    localStorage.setItem('auraspend_pin_code', newPin);
    showToast('PIN successfully changed.', 'success');
  };

  const handleAddTransaction = (newTxData: Omit<Transaction, 'id'>) => {
    const created = StorageService.addTransaction(newTxData);
    refreshAllData();

    // Check budget alert if this was a debit
    if (created.type === 'debit') {
      const budget = budgets.find((b) => b.categoryId === created.category);
      if (budget) {
        const currentMonth = created.date.substring(0, 7);
        const allTx = StorageService.getTransactions();
        const categoryTotal = allTx
          .filter((t) => t.type === 'debit' && t.category === created.category && t.date.startsWith(currentMonth))
          .reduce((sum, t) => sum + t.amount, 0);

        if (categoryTotal >= budget.monthlyLimit) {
          showToast(
            `Budget Alert: ${budget.categoryId} exceeded monthly cap (₹${categoryTotal.toLocaleString('en-IN')} / ₹${budget.monthlyLimit.toLocaleString('en-IN')})`,
            'alert'
          );
          return;
        } else if (categoryTotal >= budget.monthlyLimit * budget.alertThreshold) {
          showToast(
            `Budget Notice: ${budget.categoryId} reached ${((categoryTotal / budget.monthlyLimit) * 100).toFixed(0)}% of limit.`,
            'info'
          );
          return;
        }
      }
    }

    showToast(
      `${created.type === 'debit' ? 'Debit' : 'Credit'} of ₹${created.amount.toLocaleString('en-IN')} recorded to ledger.`,
      'success'
    );
  };

  const handleDeleteTransaction = (id: string) => {
    StorageService.deleteTransaction(id);
    refreshAllData();
    showToast('Transaction removed from ledger.', 'info');
  };

  const handleSaveBudget = (updatedBudget: CategoryBudget) => {
    const current = StorageService.getBudgets();
    const idx = current.findIndex((b) => b.id === updatedBudget.id);
    if (idx !== -1) {
      current[idx] = updatedBudget;
    } else {
      current.push(updatedBudget);
    }
    StorageService.saveBudgets(current);
    setBudgets(current);
    showToast(`Updated monthly cap for ${updatedBudget.categoryId} to ₹${updatedBudget.monthlyLimit.toLocaleString('en-IN')}.`, 'success');
  };

  const handleTriggerBankSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);

    try {
      const result = await BankSyncService.syncDailyBankFeeds((msg) => {
        // live status updates
      });
      refreshAllData();
      setIsSyncing(false);

      if (result.addedTransactions.length > 0) {
        const first = result.addedTransactions[0];
        showToast(
          `Synced ${result.addedTransactions.length} daily entries. Last: ${first.type === 'debit' ? '-' : '+'}₹${first.amount.toLocaleString('en-IN')} (${first.description})`,
          'success'
        );
      } else {
        showToast('All connected bank accounts are up to date.', 'info');
      }
    } catch (e) {
      setIsSyncing(false);
      showToast('Error syncing bank feeds. Reconnected to local cache.', 'alert');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none">
      <AndroidFrame isFrameMode={isFrameMode}>
        {/* Android Top System Status Bar */}
        <AndroidStatusBar />

        {/* Material 3 App Header */}
        <TopAppBar
          isSyncing={isSyncing}
          onTriggerBankSync={handleTriggerBankSync}
          onOpenSmsParser={() => setIsSmsModalOpen(true)}
          isFrameMode={isFrameMode}
          onToggleFrameMode={() => setIsFrameMode(!isFrameMode)}
          onOpenConfig={() => setActiveTab(activeTab === 'config' ? 'home' : 'config')}
          isConfigActive={activeTab === 'config'}
          onOpenInstall={() => setIsInstallModalOpen(true)}
        />

        {/* Floating Notification Toast */}
        {toastMessage && (
          <div className="absolute top-14 left-4 right-4 z-50 transition-all duration-300">
            <div
              className={`p-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs font-medium backdrop-blur-md ${
                toastMessage.type === 'alert'
                  ? 'bg-rose-950/90 border-rose-800 text-rose-200'
                  : toastMessage.type === 'info'
                  ? 'bg-slate-900/90 border-slate-700 text-slate-200'
                  : 'bg-emerald-950/90 border-emerald-800 text-emerald-200'
              }`}
            >
              {toastMessage.type === 'alert' ? (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
              <span className="truncate">{toastMessage.text}</span>
            </div>
          </div>
        )}

        {/* Tab View Container */}
        <main className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
          {activeTab === 'home' && (
            <HomeView
              transactions={transactions}
              accounts={accounts}
              budgets={budgets}
              onNavigateToTab={setActiveTab}
              onOpenAddModal={() => setIsAddModalOpen(true)}
              onDeleteTransaction={handleDeleteTransaction}
              onTriggerBankSync={handleTriggerBankSync}
              isSyncing={isSyncing}
            />
          )}

          {activeTab === 'transactions' && (
            <TransactionsView
              transactions={transactions}
              accounts={accounts}
              onDeleteTransaction={handleDeleteTransaction}
              onOpenAddModal={() => setIsAddModalOpen(true)}
            />
          )}

          {activeTab === 'budgets' && (
            <BudgetsView
              budgets={budgets}
              transactions={transactions}
              onSaveBudget={handleSaveBudget}
              onOpenAddModal={() => setIsAddModalOpen(true)}
            />
          )}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'sync' && (
            <CloudSyncView
              accounts={accounts}
              transactions={transactions}
              onTriggerBankSync={handleTriggerBankSync}
              isSyncing={isSyncing}
              onRefreshData={refreshAllData}
              onNavigateToConfig={() => setActiveTab('config')}
            />
          )}

          {activeTab === 'config' && (
            <AccountConfigView
              accounts={accounts}
              onAccountsUpdated={(updated) => {
                setAccounts(updated);
                showToast('Accounts configuration saved.', 'success');
              }}
              isPinEnabled={isPinEnabled}
              onTogglePin={handleTogglePin}
              savedPin={savedPin}
              onUpdatePin={handleUpdatePin}
              onLockApp={() => setIsLocked(true)}
            />
          )}
        </main>

        {/* Android Bottom Navigation Bar */}
        <BottomNavBar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onOpenAddModal={() => setIsAddModalOpen(true)}
        />

        {/* Modals */}
        <AddTransactionModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onAddTransaction={handleAddTransaction}
          accounts={accounts}
          budgets={budgets}
          transactions={transactions}
        />

        <SmsParserModal
          isOpen={isSmsModalOpen}
          onClose={() => setIsSmsModalOpen(false)}
          onAddTransaction={handleAddTransaction}
          accounts={accounts}
        />

        {/* App Security PIN Lock Modal */}
        <SecurityPinModal
          isOpen={isLocked && isPinEnabled}
          savedPin={savedPin}
          onSuccess={() => {
            setIsLocked(false);
            showToast('Security PIN verified. Welcome back!', 'success');
          }}
        />

        {/* Installation & WebAPK Download Modal */}
        <InstallModal
          isOpen={isInstallModalOpen}
          onClose={() => setIsInstallModalOpen(false)}
        />
      </AndroidFrame>
    </div>
  );
}
