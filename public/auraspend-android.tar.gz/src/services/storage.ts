import {
  BankAccount,
  CategoryBudget,
  CategoryId,
  CloudBackupRecord,
  CloudSyncState,
  MonthlyReport,
  Transaction,
} from '../types/expense';
import {
  INITIAL_ACCOUNTS,
  INITIAL_BUDGETS,
  INITIAL_CLOUD_STATE,
  INITIAL_TRANSACTIONS,
} from '../data/initialData';
import { CATEGORIES } from '../utils/formatters';

const STORAGE_KEYS = {
  TRANSACTIONS: 'auraspend_transactions_v2_inr',
  ACCOUNTS: 'auraspend_accounts_v2_inr',
  BUDGETS: 'auraspend_budgets_v2_inr',
  CLOUD_SYNC: 'auraspend_cloud_v2_inr',
};

export class StorageService {
  static getTransactions(): Transaction[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      return data ? JSON.parse(data) : INITIAL_TRANSACTIONS;
    } catch {
      return INITIAL_TRANSACTIONS;
    }
  }

  static saveTransactions(transactions: Transaction[]): void {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }

  static getAccounts(): BankAccount[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
      return data ? JSON.parse(data) : INITIAL_ACCOUNTS;
    } catch {
      return INITIAL_ACCOUNTS;
    }
  }

  static saveAccounts(accounts: BankAccount[]): void {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  }

  static getBudgets(): CategoryBudget[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BUDGETS);
      return data ? JSON.parse(data) : INITIAL_BUDGETS;
    } catch {
      return INITIAL_BUDGETS;
    }
  }

  static saveBudgets(budgets: CategoryBudget[]): void {
    localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
  }

  static getCloudSyncState(): CloudSyncState {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CLOUD_SYNC);
      return data ? JSON.parse(data) : INITIAL_CLOUD_STATE;
    } catch {
      return INITIAL_CLOUD_STATE;
    }
  }

  static saveCloudSyncState(state: CloudSyncState): void {
    localStorage.setItem(STORAGE_KEYS.CLOUD_SYNC, JSON.stringify(state));
  }

  static addTransaction(
    tx: Omit<Transaction, 'id'> & { id?: string },
    updateAccountBalance = true
  ): Transaction {
    const transactions = this.getTransactions();
    const newTx: Transaction = {
      ...tx,
      id: tx.id || `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };

    transactions.unshift(newTx);
    this.saveTransactions(transactions);

    if (updateAccountBalance && tx.accountId) {
      const accounts = this.getAccounts();
      const accountIndex = accounts.findIndex((a) => a.id === tx.accountId);
      if (accountIndex !== -1) {
        const acc = accounts[accountIndex];
        if (tx.type === 'debit') {
          if (acc.type === 'credit') {
            acc.balance += tx.amount; // credit card balance owed increases
          } else {
            acc.balance -= tx.amount;
          }
        } else {
          // credit
          if (acc.type === 'credit') {
            acc.balance = Math.max(0, acc.balance - tx.amount); // paying down card
          } else {
            acc.balance += tx.amount;
          }
        }
        accounts[accountIndex] = acc;
        this.saveAccounts(accounts);
      }
    }

    return newTx;
  }

  static deleteTransaction(id: string): void {
    const transactions = this.getTransactions();
    const target = transactions.find((t) => t.id === id);
    if (!target) return;

    const filtered = transactions.filter((t) => t.id !== id);
    this.saveTransactions(filtered);

    // Revert balance
    if (target.accountId) {
      const accounts = this.getAccounts();
      const accountIndex = accounts.findIndex((a) => a.id === target.accountId);
      if (accountIndex !== -1) {
        const acc = accounts[accountIndex];
        if (target.type === 'debit') {
          if (acc.type === 'credit') {
            acc.balance -= target.amount;
          } else {
            acc.balance += target.amount;
          }
        } else {
          if (acc.type === 'credit') {
            acc.balance += target.amount;
          } else {
            acc.balance -= target.amount;
          }
        }
        accounts[accountIndex] = acc;
        this.saveAccounts(accounts);
      }
    }
  }

  static generateMonthlyReport(monthStr: string): MonthlyReport {
    // monthStr is format 'YYYY-MM', e.g., '2026-10'
    const transactions = this.getTransactions();
    const budgets = this.getBudgets();

    const monthTxs = transactions.filter((t) => t.date.startsWith(monthStr));

    let totalDebit = 0;
    let totalCredit = 0;
    const categoryTotals: Record<CategoryId, { total: number; count: number }> = {} as any;
    const merchantTotals: Record<string, { total: number; count: number }> = {};

    monthTxs.forEach((tx) => {
      if (tx.type === 'debit') {
        totalDebit += tx.amount;
        if (!categoryTotals[tx.category]) {
          categoryTotals[tx.category] = { total: 0, count: 0 };
        }
        categoryTotals[tx.category].total += tx.amount;
        categoryTotals[tx.category].count += 1;

        // Clean merchant name
        const cleanMerchant = tx.description.split(' #')[0].split(' - ')[0].trim();
        if (!merchantTotals[cleanMerchant]) {
          merchantTotals[cleanMerchant] = { total: 0, count: 0 };
        }
        merchantTotals[cleanMerchant].total += tx.amount;
        merchantTotals[cleanMerchant].count += 1;
      } else {
        totalCredit += tx.amount;
      }
    });

    const netSavings = totalCredit - totalDebit;
    const savingsRate = totalCredit > 0 ? Math.max(0, (netSavings / totalCredit) * 100) : 0;

    // Category breakdown
    const categoryBreakdown = Object.entries(categoryTotals)
      .map(([catId, data]) => {
        const id = catId as CategoryId;
        const catDef = CATEGORIES[id] || { name: id, color: '#64748B' };
        const budget = budgets.find((b) => b.categoryId === id)?.monthlyLimit;
        const percentage = totalDebit > 0 ? (data.total / totalDebit) * 100 : 0;
        const isOverBudget = budget ? data.total > budget : false;

        return {
          categoryId: id,
          categoryName: catDef.name,
          color: catDef.color,
          total: data.total,
          count: data.count,
          percentage,
          budget,
          isOverBudget,
        };
      })
      .sort((a, b) => b.total - a.total);

    // Top merchants
    const topMerchants = Object.entries(merchantTotals)
      .map(([merchant, data]) => ({
        merchant,
        total: data.total,
        count: data.count,
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);

    // Daily average based on days in month or today's day
    const [year, month] = monthStr.split('-').map(Number);
    const isCurrentMonth =
      new Date().getFullYear() === year && new Date().getMonth() + 1 === month;
    const daysEvaluated = isCurrentMonth
      ? Math.max(1, new Date().getDate())
      : new Date(year, month, 0).getDate();

    const dailySpendAverage = totalDebit / daysEvaluated;

    // Automated monthly insights
    const insights: string[] = [];
    if (categoryBreakdown.length > 0) {
      const topCat = categoryBreakdown[0];
      insights.push(
        `Highest expenditure category was ${topCat.categoryName} representing ${topCat.percentage.toFixed(1)}% of total debit spend (₹${topCat.total.toLocaleString('en-IN')}).`
      );
    }

    const overBudgetCats = categoryBreakdown.filter((c) => c.isOverBudget);
    if (overBudgetCats.length > 0) {
      insights.push(
        `Attention: ${overBudgetCats.map((c) => c.categoryName).join(', ')} exceeded allocated monthly budget caps.`
      );
    } else {
      insights.push(
        `All active category budgets remained disciplined within allocated thresholds this month.`
      );
    }

    if (totalCredit > 0) {
      insights.push(
        `Net savings achieved: ₹${netSavings.toLocaleString('en-IN')} with an automated ${savingsRate.toFixed(1)}% monthly savings rate.`
      );
    }

    return {
      month: monthStr,
      totalDebit,
      totalCredit,
      netSavings,
      savingsRate,
      categoryBreakdown,
      topMerchants,
      dailySpendAverage,
      insights,
    };
  }

  static createCloudBackupSnapshot(): CloudBackupRecord {
    const transactions = this.getTransactions();
    const accounts = this.getAccounts();
    const budgets = this.getBudgets();
    const payload = JSON.stringify({ transactions, accounts, budgets, timestamp: new Date().toISOString() });

    const sizeKb = parseFloat((new Blob([payload]).size / 1024).toFixed(2));
    const record: CloudBackupRecord = {
      id: `bk-${Date.now()}`,
      timestamp: new Date().toLocaleString(),
      recordCount: transactions.length,
      sizeKb,
      hash: 'sha256-' + Math.random().toString(16).substring(2, 10),
    };

    const cloudState = this.getCloudSyncState();
    cloudState.lastSyncedAt = 'Just now';
    cloudState.storageUsedKb = sizeKb;
    cloudState.backupHistory.unshift(record);
    if (cloudState.backupHistory.length > 8) {
      cloudState.backupHistory.pop();
    }
    this.saveCloudSyncState(cloudState);

    return record;
  }

  static resetToDefault(): void {
    localStorage.removeItem(STORAGE_KEYS.TRANSACTIONS);
    localStorage.removeItem(STORAGE_KEYS.ACCOUNTS);
    localStorage.removeItem(STORAGE_KEYS.BUDGETS);
    localStorage.removeItem(STORAGE_KEYS.CLOUD_SYNC);
  }
}
