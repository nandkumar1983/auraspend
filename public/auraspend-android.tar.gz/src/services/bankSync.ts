import { CategoryId, Transaction } from '../types/expense';
import { StorageService } from './storage';
import { getCurrentTimeString, getTodayString } from '../utils/formatters';

export interface ParsedSmsResult {
  success: boolean;
  type: 'debit' | 'credit';
  amount: number;
  description: string;
  category: CategoryId;
  accountId: string;
  rawText: string;
  bankDetected?: string;
  referenceNumber?: string;
}

export class BankSyncService {
  // Pre-configured bank feed templates for realistic daily automated sync
  private static MOCK_PENDING_FEED: Array<Omit<Transaction, 'id' | 'date' | 'time'>> = [
    {
      type: 'debit',
      amount: 450.0,
      category: 'dining',
      accountId: 'icici-coral',
      description: 'Blue Tokai Specialty Coffee Roasters',
      source: 'bank_sync',
      bankReference: 'UPI/BLUETOKAI/99412',
      status: 'cleared',
      tags: ['daily-feed', 'coffee', 'upi'],
    },
    {
      type: 'debit',
      amount: 1420.0,
      category: 'groceries',
      accountId: 'icici-coral',
      description: 'DMart Supercenter Malad',
      source: 'bank_sync',
      bankReference: 'POS/DMART/90124',
      status: 'cleared',
      tags: ['daily-feed', 'groceries'],
    },
    {
      type: 'credit',
      amount: 250.0,
      category: 'other',
      accountId: 'icici-coral',
      description: 'RuPay Cashback Reward Credited',
      source: 'bank_sync',
      bankReference: 'CB/RUPAY/OCT26/01',
      status: 'cleared',
      tags: ['cashback', 'credit'],
    },
    {
      type: 'debit',
      amount: 600.0,
      category: 'transport',
      accountId: 'hdfc-sal',
      description: 'Mumbai Metro Card Auto-Topup',
      source: 'bank_sync',
      bankReference: 'ACH-MMRCL-METRO-091',
      status: 'cleared',
      tags: ['commute'],
    },
    {
      type: 'credit',
      amount: 8500.0,
      category: 'freelance',
      accountId: 'hdfc-sal',
      description: 'Client Project Milestone via NEFT',
      source: 'bank_sync',
      bankReference: 'NEFT/CLIENT/MILESTONE-02',
      status: 'cleared',
      tags: ['income'],
    },
  ];

  static async syncDailyBankFeeds(onProgress?: (msg: string) => void): Promise<{
    addedTransactions: Transaction[];
    syncedAccountsCount: number;
  }> {
    if (onProgress) onProgress('Connecting to RBI Account Aggregator (AA) Gateway...');
    await new Promise((r) => setTimeout(r, 600));

    if (onProgress) onProgress('Handshaking with HDFC Bank & ICICI Bank secure endpoints...');
    await new Promise((r) => setTimeout(r, 700));

    if (onProgress) onProgress('Reconciling daily credit and debit UPI & card entries...');
    await new Promise((r) => setTimeout(r, 500));

    const existing = StorageService.getTransactions();
    const today = getTodayString();
    const time = getCurrentTimeString();

    const added: Transaction[] = [];

    // Pick 1 to 2 fresh items from feed that don't already exist with same bank ref
    for (const item of this.MOCK_PENDING_FEED) {
      const alreadyHas = existing.some(
        (t) => t.bankReference === item.bankReference && t.date === today
      );

      if (!alreadyHas) {
        const newTx = StorageService.addTransaction({
          ...item,
          date: today,
          time: time,
        });
        added.push(newTx);
        if (added.length >= 2) break; // sync up to 2 items per manual trigger
      }
    }

    // If all sample feeds already synced, generate a unique fresh daily debit or credit
    if (added.length === 0) {
      const isCredit = Math.random() > 0.65;
      const randomAmount = isCredit
        ? parseFloat((Math.random() * 5000 + 1000).toFixed(2))
        : parseFloat((Math.random() * 800 + 120).toFixed(2));

      const newTx = StorageService.addTransaction({
        type: isCredit ? 'credit' : 'debit',
        amount: randomAmount,
        category: isCredit ? 'freelance' : 'dining',
        accountId: isCredit ? 'hdfc-sal' : 'icici-coral',
        description: isCredit ? 'UPI Referral Bonus Credited' : 'Chai Point Express',
        source: 'bank_sync',
        bankReference: `UPI/FEED/${Date.now().toString().slice(-6)}`,
        status: 'cleared',
        date: today,
        time: time,
        tags: ['auto-synced'],
      });
      added.push(newTx);
    }

    // Update bank accounts sync timestamp
    const accounts = StorageService.getAccounts();
    const updatedAccounts = accounts.map((acc) => ({
      ...acc,
      lastSyncedAt: 'Today at ' + time,
      syncStatus: 'connected' as const,
    }));
    StorageService.saveAccounts(updatedAccounts);

    return {
      addedTransactions: added,
      syncedAccountsCount: accounts.length,
    };
  }

  static parseSmsOrNotification(text: string): ParsedSmsResult {
    const raw = text.trim();
    if (!raw) {
      return {
        success: false,
        type: 'debit',
        amount: 0,
        description: '',
        category: 'other',
        accountId: 'apple-card',
        rawText: text,
      };
    }

    // Detect type: debit vs credit
    const isDebit =
      /debited|spent|purchase|paid|charge|sent|deducted|withdrawn|dr\b/i.test(raw);
    const isCredit =
      /credited|deposited|received|refund|cashback|cr\b|deposit/i.test(raw);

    const type: 'debit' | 'credit' = isCredit && !isDebit ? 'credit' : 'debit';

    // Detect currency & amount: e.g. $45.20, USD 45.20, INR 450.00, Rs. 450, 45.20 USD
    const amountMatch = raw.match(
      /(?:[$€£]|USD|EUR|GBP|INR|Rs\.?)\s*([\d,]+(?:\.\d{1,2})?)|([\d,]+(?:\.\d{1,2})?)\s*(?:USD|EUR|GBP|INR)/i
    ) || raw.match(/([\d,]+\.\d{2})/);

    let amount = 0;
    if (amountMatch) {
      const matchVal = amountMatch[1] || amountMatch[2];
      amount = parseFloat(matchVal.replace(/,/g, ''));
    }

    // Detect merchant or description
    let description = 'Bank Transaction';
    const atMatch = raw.match(
      /(?:at|to|info|for|merchant:?)\s+([A-Za-z0-9\s&'.#\-]+?)(?:\s+on|\s+ref|\s+avl|\s+bal|\.|$)/i
    );
    if (atMatch && atMatch[1].trim()) {
      description = atMatch[1].trim();
    } else {
      const words = raw.split(/\s+/).slice(0, 5).join(' ');
      description = words.length > 30 ? words.substring(0, 30) + '...' : words;
    }

    // Detect account
    let accountId = 'hdfc-sal';
    if (/hdfc|4128/i.test(raw)) {
      accountId = 'hdfc-sal';
    } else if (/icici|coral|8902|rupay/i.test(raw)) {
      accountId = 'icici-coral';
    } else if (/sbi|state bank|7731/i.test(raw)) {
      accountId = 'sbi-sav';
    } else if (/upi|paytm|phonepe|gpay|cash|wallet/i.test(raw)) {
      accountId = 'upi-cash';
    }

    // Detect Category
    let category: CategoryId = 'other';
    const lowerDesc = (description + ' ' + raw).toLowerCase();
    if (/grocery|supermarket|mart|dmart|blinkit|zepto|instamart|nature basket|bigbasket/i.test(lowerDesc)) {
      category = 'groceries';
    } else if (/coffee|cafe|restaurant|bistro|food|swiggy|zomato|starbucks|chai|dhaba|biryani/i.test(lowerDesc)) {
      category = 'dining';
    } else if (/uber|ola|rapido|fuel|petrol|diesel|iocl|bpcl|hpcl|metro|irctc|train/i.test(lowerDesc)) {
      category = 'transport';
    } else if (/amazon|flipkart|myntra|clothes|apparel|uniqlo|tata cliq|ajio/i.test(lowerDesc)) {
      category = 'shopping';
    } else if (/electric|adani|bescom|tneb|power|water|internet|jio|airtel|broadband|bill|bbps/i.test(lowerDesc)) {
      category = 'utilities';
    } else if (/rent|lease|mortgage|apartment|maintenance|society/i.test(lowerDesc)) {
      category = 'housing';
    } else if (/cinema|theatre|pvr|inox|netflix|spotify|hotstar|prime/i.test(lowerDesc)) {
      category = 'entertainment';
    } else if (/pharmacy|apollo|medplus|1mg|health|clinic|doctor|hospital/i.test(lowerDesc)) {
      category = 'health';
    } else if (/salary|payroll|wages|infosys|tcs|wipro/i.test(lowerDesc)) {
      category = 'salary';
    }

    // Reference number
    const refMatch = raw.match(/(?:ref|txn|rrn|id):?\s*([A-Za-z0-9\-]+)/i);
    const referenceNumber = refMatch ? refMatch[1] : `SMS-${Date.now().toString().slice(-5)}`;

    return {
      success: amount > 0,
      type,
      amount: amount > 0 ? amount : 25.0,
      description: description || 'Mobile Debit Entry',
      category,
      accountId,
      rawText: text,
      referenceNumber,
    };
  }
}
