import React, { useState } from 'react';
import {
  ShoppingCart,
  Utensils,
  ShoppingBag,
  Car,
  Zap,
  Home,
  Film,
  Activity,
  Briefcase,
  Award,
  TrendingUp,
  Repeat,
  MoreHorizontal,
  Trash2,
  CheckCircle2,
  Clock,
  Landmark,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';
import { BankAccount, Transaction } from '../types/expense';
import { CATEGORIES, formatCurrency, formatDateShort } from '../utils/formatters';

interface TransactionItemProps {
  transaction: Transaction;
  account?: BankAccount;
  onDelete?: (id: string) => void;
}

const CATEGORY_ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  ShoppingCart,
  Utensils,
  ShoppingBag,
  Car,
  Zap,
  Home,
  Film,
  Activity,
  Briefcase,
  Award,
  TrendingUp,
  Repeat,
  MoreHorizontal,
};

export const TransactionItem: React.FC<TransactionItemProps> = ({
  transaction,
  account,
  onDelete,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const catDef = CATEGORIES[transaction.category] || {
    name: transaction.category,
    icon: 'MoreHorizontal',
    color: '#64748B',
  };
  const IconComponent = CATEGORY_ICON_MAP[catDef.icon] || MoreHorizontal;

  const isDebit = transaction.type === 'debit';

  return (
    <div className="bg-slate-900/70 hover:bg-slate-900 border border-slate-800/80 rounded-2xl transition-all overflow-hidden">
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between p-3 cursor-pointer select-none"
      >
        {/* Left Category Icon */}
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm"
            style={{
              backgroundColor: `${catDef.color}20`,
              color: catDef.color,
            }}
          >
            <IconComponent className="w-5 h-5" />
          </div>

          <div className="min-w-0">
            <h4 className="text-xs font-semibold text-slate-100 truncate">
              {transaction.description}
            </h4>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
              <span>{catDef.name}</span>
              <span>·</span>
              <span className="truncate">{account ? account.name.split(' ')[0] : 'Bank'}</span>
              <span>·</span>
              <span>{transaction.time || formatDateShort(transaction.date)}</span>
            </div>
          </div>
        </div>

        {/* Right Amount */}
        <div className="flex items-center gap-1.5 shrink-0 pl-2">
          <div className="text-right">
            <span
              className={`text-xs font-bold font-mono tabular-nums block ${
                isDebit ? 'text-slate-100' : 'text-emerald-400'
              }`}
            >
              {isDebit ? '-' : '+'}
              {formatCurrency(transaction.amount)}
            </span>
            <span className="text-[10px] text-slate-500 font-medium">
              {transaction.source === 'bank_sync'
                ? 'Bank Sync'
                : transaction.source === 'sms_parser'
                ? 'SMS Parse'
                : 'Manual'}
            </span>
          </div>
          <ChevronRight
            className={`w-3.5 h-3.5 text-slate-500 transition-transform ${
              isExpanded ? 'rotate-90' : ''
            }`}
          />
        </div>
      </div>

      {/* Expanded Details Drawer */}
      {isExpanded && (
        <div className="px-3 pb-3 pt-1 border-t border-slate-800/60 bg-slate-950/40 text-[11px] space-y-2">
          <div className="grid grid-cols-2 gap-2 text-slate-300">
            <div>
              <span className="text-[10px] text-slate-500 block">Bank Account</span>
              <span className="font-medium flex items-center gap-1">
                <Landmark className="w-3 h-3 text-slate-400" />
                {account ? `${account.name} (${account.accountNumber})` : 'Connected Bank'}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Status & Verification</span>
              <span className="font-medium text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                Reconciled ({transaction.status})
              </span>
            </div>
            {transaction.bankReference && (
              <div className="col-span-2">
                <span className="text-[10px] text-slate-500 block">Bank Feed Reference</span>
                <span className="font-mono text-slate-400 text-[10px] select-all">
                  {transaction.bankReference}
                </span>
              </div>
            )}
            {transaction.receiptNote && (
              <div className="col-span-2">
                <span className="text-[10px] text-slate-500 block">Receipt Note</span>
                <span className="text-slate-300 italic">{transaction.receiptNote}</span>
              </div>
            )}
          </div>

          {onDelete && (
            <div className="flex justify-end pt-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(transaction.id);
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-colors text-[11px] font-medium"
              >
                <Trash2 className="w-3 h-3" />
                Delete Entry
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
