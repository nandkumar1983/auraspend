import React from 'react';
import { LayoutDashboard, ReceiptText, PieChart, BarChart3, CloudLightning, Plus } from 'lucide-react';

export type ActiveTab = 'home' | 'transactions' | 'budgets' | 'reports' | 'sync' | 'config';

interface BottomNavBarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onOpenAddModal: () => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  onOpenAddModal,
}) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: LayoutDashboard },
    { id: 'transactions', label: 'Ledger', icon: ReceiptText },
    { id: 'budgets', label: 'Budgets', icon: PieChart },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'sync', label: 'Bank & Cloud', icon: CloudLightning },
  ];

  return (
    <div className="relative z-40 bg-slate-900/95 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 shadow-2xl">
      <div className="flex items-center justify-around relative max-w-md mx-auto">
        {tabs.slice(0, 2).map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as ActiveTab)}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 transition-all duration-200 rounded-xl ${
                isActive ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`relative px-3 py-1 rounded-full transition-colors ${
                  isActive ? 'bg-emerald-500/15' : 'bg-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              </div>
              <span className="text-[11px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* Central Floating Quick Entry (+) FAB */}
        <div className="relative -top-4 flex items-center justify-center px-1">
          <button
            onClick={onOpenAddModal}
            className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 shadow-lg shadow-emerald-500/25 flex items-center justify-center transform active:scale-90 hover:scale-105 transition-all duration-200 border-2 border-slate-900 ring-2 ring-emerald-500/20"
            title="Quick Add Debit or Credit"
            aria-label="Add Transaction"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>

        {tabs.slice(2).map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as ActiveTab)}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 transition-all duration-200 rounded-xl ${
                isActive ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`relative px-3 py-1 rounded-full transition-colors ${
                  isActive ? 'bg-emerald-500/15' : 'bg-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              </div>
              <span className="text-[11px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Android Home Bar Pill Indicator */}
      <div className="w-28 h-1 bg-slate-700/60 rounded-full mx-auto mt-2" />
    </div>
  );
};
