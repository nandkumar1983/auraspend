import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Download,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  QrCode,
  FileCode,
} from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [installStatus, setInstallStatus] = useState<string | null>(null);

  const sharedUrl =
    typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : 'https://ais-dev-3rsahelvcmfz5ls4j4ohyy-174631317751.asia-east1.run.app';

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setInstallStatus('Installation initiated on your device!');
        setDeferredPrompt(null);
      }
    } else {
      setInstallStatus('To install: Open browser menu (⋮) -> Tap "Install app" or "Add to Home screen"');
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(sharedUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  // Generate downloadable Android installation package
  const handleDownloadPackage = () => {
    const packageFiles = {
      name: 'AuraSpend-Android-Installer-Package',
      version: '2.0.0',
      manifestUrl: `${window.location.origin}/manifest.json`,
      iconUrl: `${window.location.origin}/icon.svg`,
      serviceWorkerUrl: `${window.location.origin}/sw.js`,
      installInstructions: `# AuraSpend Android App Installation Guide

## Option 1: Direct WebAPK Install (No PC required)
1. Open this link on your Android device in Google Chrome or Samsung Internet:
   ${sharedUrl}
2. Tap the 3 dots (⋮) menu in the top right.
3. Tap "Install App" or "Add to Home screen".
4. Android will generate a native WebAPK application on your home screen.

## Option 2: Build Native Android APK (.apk) via Google Bubblewrap
1. Open terminal on your computer.
2. Install Bubblewrap CLI:
   npm install -g @bubblewrap/cli
3. Initialize the Android project:
   bubblewrap init --manifest=${sharedUrl}/manifest.json
4. Build the APK:
   bubblewrap build
5. Sideload the generated "app-release-signed.apk" to your Android phone via adb:
   adb install -r app-release-signed.apk
`,
    };

    const blob = new Blob([JSON.stringify(packageFiles, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AuraSpend_Android_Installation_Files.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-md p-0 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Android Installation Center</h2>
              <p className="text-[10px] text-slate-400">Install as native WebAPK or build .apk</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs overflow-y-auto">
          {/* Primary Action: Direct WebAPK Install Button */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-xs flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                1-Tap Android WebAPK Installation
              </span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-2 py-0.5 rounded-full font-semibold">
                Instant
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Installs AuraSpend directly onto your Android device home screen with standalone windowing, offline capabilities, and hardware-accelerated rendering.
            </p>

            <button
              onClick={handleInstallClick}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 hover:opacity-95 active:scale-98 transition-all"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              {deferredPrompt ? 'Install App on This Device Now' : 'Launch Android Installation'}
            </button>

            {installStatus && (
              <p className="text-[10px] text-amber-300 bg-amber-950/40 p-2 rounded-lg border border-amber-800/40">
                {installStatus}
              </p>
            )}
          </div>

          {/* Sideload & Installation Files Download */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-xs flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                Android Installation Descriptor Files
              </span>
              <span className="text-[10px] text-slate-500 font-mono">v2.0.0</span>
            </div>

            <p className="text-[11px] text-slate-400">
              Download the manifest and installation package containing the manifest.json, service worker, and APK compiler config:
            </p>

            <button
              onClick={handleDownloadPackage}
              className="w-full py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-200 font-medium flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              Download Installation Package (.json)
            </button>
          </div>

          {/* QR Code / Open On Android Phone */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="font-bold text-white text-xs flex items-center gap-1.5">
              <QrCode className="w-3.5 h-3.5 text-emerald-400" />
              Open on Android Phone via Link
            </span>

            <p className="text-[11px] text-slate-400">
              Open your Android phone's camera or browser and paste this URL to install:
            </p>

            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-xl p-1.5">
              <input
                type="text"
                readOnly
                value={sharedUrl}
                className="flex-1 bg-transparent text-[11px] text-slate-300 font-mono px-2 focus:outline-none truncate"
              />
              <button
                onClick={handleCopyLink}
                className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-xs font-semibold flex items-center gap-1 shrink-0 transition-colors"
              >
                {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {isCopied ? 'Copied!' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Manual Step-by-Step Guide */}
          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1.5 text-[11px] text-slate-400">
            <span className="font-bold text-slate-300 block">Manual Chrome Android Steps:</span>
            <p>1. Open the URL in <strong>Google Chrome</strong> on Android.</p>
            <p>2. Tap the <strong>⋮ (three dots)</strong> menu in the upper-right corner.</p>
            <p>3. Tap <strong>"Install app"</strong> (or "Add to Home Screen").</p>
            <p>4. The app will install with its green ₹ icon and launch in full-screen standalone mode.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
