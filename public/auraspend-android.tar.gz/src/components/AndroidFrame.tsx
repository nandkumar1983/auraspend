import React from 'react';

interface AndroidFrameProps {
  children: React.ReactNode;
  isFrameMode: boolean;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children, isFrameMode }) => {
  if (!isFrameMode) {
    return (
      <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between">
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex items-center justify-center p-2 sm:p-6 md:p-8">
      {/* Outer Phone Shell with subtle titanium border and shadow */}
      <div className="relative w-full max-w-[430px] h-[890px] max-h-[96vh] rounded-[48px] bg-slate-900 border-[7px] border-slate-800 shadow-2xl ring-1 ring-white/10 flex flex-col overflow-hidden">
        {/* Hardware buttons on phone rim */}
        <div className="absolute -left-[10px] top-28 w-[3px] h-12 bg-slate-700 rounded-l" />
        <div className="absolute -left-[10px] top-44 w-[3px] h-12 bg-slate-700 rounded-l" />
        <div className="absolute -right-[10px] top-36 w-[3px] h-16 bg-slate-700 rounded-r" />

        {/* Inner Phone Screen Content */}
        <div className="relative flex-1 flex flex-col w-full h-full bg-slate-950 overflow-hidden">
          {children}
        </div>
      </div>
    </div>
  );
};
