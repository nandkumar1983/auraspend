import React, { useState } from 'react';
import { X, ArrowDownRight, ArrowUpRight, Check, Calendar, Clock, Tag, FileText } from 'lucide-react';
import { BankAccount, CategoryBudget, CategoryId, Transaction, TransactionType } from '../types/expense';
import { CATEGORIES, getCurrentTimeString, getTodayString } from '../utils/formatters';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTransaction: (tx: Omit<Transaction, 'id'>) => void;
  accounts: BankAccount[];
  budgets: CategoryBudget[];
  transactions: Transaction[];
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onAddTransaction,
  accounts,
  budgets,
  transactions,
}) => {
  const [type, setType] = useState<TransactionType>('debit');
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState<CategoryId>('groceries');
  const [accountId, setAccountId] = useState<string>(accounts[0]?.id || 'apple-card');
  const [description, setDescription] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayString());
  const [time, setTime] = useState<string>(getCurrentTimeString());
  const [receiptNote, setReceiptNote] = useState<string>('');
  const [tagInput, setTagInput] = useState<string>('');

  if (!isOpen) return null;

  const numAmount = parseFloat(amount) || 0;

  // Compute live budget impact if this is a debit
  const budgetForCategory = budgets.find((b) => b.categoryId === category);
  const currentMonth = date.substring(0, 7);
  const currentCategorySpend = transactions
    .filter((t) => t.type === 'debit' && t.category === category && t.date.startsWith(currentMonth))
    .reduce((sum, t) => sum + t.amount, 0);

  const newProjectedSpend = currentCategorySpend + (type === 'debit' ? numAmount : 0);
  const budgetLimit = budgetForCategory?.monthlyLimit || 0;
  const projectedPercent = budgetLimit > 0 ? (newProjectedSpend / budgetLimit) * 100 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (numAmount <= 0) return;

    const tags = tagInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    onAddTransaction({
      type,
      amount: numAmount,
      category,
      accountId,
      description: description.trim() || (type === 'debit' ? 'Expense Entry' : 'Income Entry'),
      date,
      time,
      source: 'manual',
      status: 'cleared',
      receiptNote: receiptNote.trim() || undefined,
      tags: tags.length > 0 ? tags : undefined,
    });

    // Reset and close
    setAmount('');
    setDescription('');
    setReceiptNote('');
    setTagInput('');
    onClose();
  };

  const quickAmounts = type === 'debit' ? [50, 100, 250, 500, 1000] : [500, 1000, 5000, 10000];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-4 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white">Add Entry</span>
            <span className="text-xs text-slate-400">· Daily Ledger (₹ INR)</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-5 py-3 space-y-4 text-xs">
          {/* Credit vs Debit Type Selector */}
          <div className="grid grid-cols-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => {
                setType('debit');
                setCategory('groceries');
              }}
              className={`flex items-center justify-center gap-2 py-2.5 rounded-lg font-semibold transition-all ${
                type === 'debit'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ArrowDownRight className="w-4 h-4" />
              Debit (Expense)
            </button>
            <button
              type="button"
              onClick={() => {
                setType('credit');
                setCategory('salary');
              }}
              className={`flex items-center justify-center gap-2 py-2.5 rounded-lg font-semibold transition-all ${
                type === 'credit'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              Credit (Income)
            </button>
          </div>

          {/* Amount Input with big numerals */}
          <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800 text-center">
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              {type === 'debit' ? 'Debit Amount (₹)' : 'Credit Amount (₹)'}
            </label>
            <div className="flex items-center justify-center gap-1">
              <span className="text-2xl font-bold text-slate-400">₹</span>
              <input
                type="number"
                step="1"
                min="1"
                autoFocus
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-48 text-3xl font-extrabold text-white text-center bg-transparent focus:outline-none placeholder-slate-600 font-mono"
                required
              />
            </div>

            {/* Quick Amount Adders */}
            <div className="flex items-center justify-center gap-1.5 mt-2.5">
              {quickAmounts.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => {
                    const current = parseFloat(amount) || 0;
                    setAmount((current + q).toFixed(0));
                  }}
                  className="px-2 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-mono text-[11px] transition-colors"
                >
                  +₹{q}
                </button>
              ))}
            </div>
          </div>

          {/* Real-time Budget Impact Meter (Debit only) */}
          {type === 'debit' && budgetLimit > 0 && numAmount > 0 && (
            <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] text-slate-300 mb-1">
                <span>Budget Impact ({CATEGORIES[category]?.name || category})</span>
                <span className="font-mono tabular-nums">
                  ₹{newProjectedSpend.toLocaleString('en-IN')} / ₹{budgetLimit.toLocaleString('en-IN')} ({projectedPercent.toFixed(0)}%)
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 rounded-full ${
                    projectedPercent > 100
                      ? 'bg-rose-500'
                      : projectedPercent > 80
                      ? 'bg-amber-400'
                      : 'bg-emerald-400'
                  }`}
                  style={{ width: `${Math.min(100, projectedPercent)}%` }}
                />
              </div>
              {projectedPercent > 100 && (
                <p className="text-[10px] text-rose-400 mt-1 font-medium">
                  Warning: This entry will put this category over the allocated monthly budget.
                </p>
              )}
            </div>
          )}

          {/* Merchant / Description */}
          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              Description / Merchant
            </label>
            <input
              type="text"
              placeholder={type === 'debit' ? 'e.g. DMart, Swiggy, Indian Oil, Electricity bill' : 'e.g. Salary, Client payout, Bonus'}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Account Selector */}
          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              Bank Account / Wallet
            </label>
            <select
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-emerald-500"
            >
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id}>
                  {acc.name} ({acc.accountNumber}) · Bal: ${acc.balance.toFixed(2)}
                </option>
              ))}
            </select>
          </div>

          {/* Category Grid */}
          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1.5">Category</label>
            <div className="grid grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-1 bg-slate-950/60 rounded-xl border border-slate-800/80">
              {Object.values(CATEGORIES)
                .filter((cat) => (type === 'debit' ? cat.type !== 'income' : cat.type !== 'expense'))
                .map((cat) => {
                  const isSelected = category === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCategory(cat.id)}
                      className={`flex flex-col items-start p-2 rounded-lg text-left transition-all ${
                        isSelected
                          ? 'bg-slate-800 text-white ring-1 ring-emerald-400'
                          : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 w-full">
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: cat.color }}
                        />
                        <span className="text-[11px] font-medium truncate">{cat.name}</span>
                      </div>
                    </button>
                  );
                })}
            </div>
          </div>

          {/* Date & Time Row */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-1">
                <Calendar className="w-3 h-3 text-slate-400" /> Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-1">
                <Clock className="w-3 h-3 text-slate-400" /> Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none"
              />
            </div>
          </div>

          {/* Optional Notes & Tags */}
          <div className="space-y-2 pt-1 border-t border-slate-800/80">
            <div>
              <label className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-1">
                <FileText className="w-3 h-3 text-slate-400" /> Receipt Note (optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Warranty attached, Split with Alex"
                value={receiptNote}
                onChange={(e) => setReceiptNote(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-1">
                <Tag className="w-3 h-3 text-slate-400" /> Tags (comma-separated)
              </label>
              <input
                type="text"
                placeholder="e.g. tax-deductible, personal, trip"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={numAmount <= 0}
              className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 text-sm transition-all ${
                type === 'debit'
                  ? 'bg-gradient-to-r from-rose-500 to-amber-600 text-white shadow-lg shadow-rose-900/30'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-lg shadow-emerald-900/30'
              } disabled:opacity-40 disabled:cursor-not-allowed`}
            >
              <Check className="w-4 h-4 stroke-[3]" />
              Save {type === 'debit' ? 'Debit' : 'Credit'} Entry
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
