import React, { useState } from 'react';
import { X, Sparkles, Check, ArrowDownRight, ArrowUpRight, Copy } from 'lucide-react';
import { BankAccount, Transaction } from '../types/expense';
import { BankSyncService, ParsedSmsResult } from '../services/bankSync';
import { getCurrentTimeString, getTodayString } from '../utils/formatters';

interface SmsParserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTransaction: (tx: Omit<Transaction, 'id'>) => void;
  accounts: BankAccount[];
}

const SAMPLE_ALERTS = [
  {
    bank: 'HDFC Bank (UPI)',
    text: 'HDFC Bank: A/C ending 4128 debited for Rs 1,450.00 on 18-Oct at DMart Supercenter via UPI. Avl Bal: Rs 83,050.00. Ref 429104',
  },
  {
    bank: 'ICICI Bank Card',
    text: 'ICICI Bank: Txn of Rs 480.00 approved on Credit Card ending 8902 at Starbucks Bandra on 18-Oct. Avl Limit: Rs 2,49,520.00',
  },
  {
    bank: 'SBI Salary Credit',
    text: 'SBI Alert: Your A/C ending 7731 credited by Rs 85,000.00 on 18-Oct by Infosys Tech Salary. Total Bal: Rs 3,20,000.00',
  },
  {
    bank: 'Google Pay / Swiggy',
    text: 'Google Pay: Paid Rs 350.00 to Swiggy Food Delivery via UPI ID user@okhdfc. UTR Ref: 4921048812',
  },
];

export const SmsParserModal: React.FC<SmsParserModalProps> = ({
  isOpen,
  onClose,
  onAddTransaction,
  accounts,
}) => {
  const [inputText, setInputText] = useState<string>(SAMPLE_ALERTS[0].text);
  const [parsed, setParsed] = useState<ParsedSmsResult>(() =>
    BankSyncService.parseSmsOrNotification(SAMPLE_ALERTS[0].text)
  );

  if (!isOpen) return null;

  const handleTextChange = (text: string) => {
    setInputText(text);
    const res = BankSyncService.parseSmsOrNotification(text);
    setParsed(res);
  };

  const handleApply = () => {
    if (!parsed.amount) return;

    onAddTransaction({
      type: parsed.type,
      amount: parsed.amount,
      category: parsed.category,
      accountId: parsed.accountId || accounts[0]?.id || 'chase-chk',
      description: parsed.description,
      date: getTodayString(),
      time: getCurrentTimeString(),
      source: 'sms_parser',
      bankReference: parsed.referenceNumber,
      status: 'cleared',
      tags: ['sms-parsed', parsed.type],
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-bold text-white">Bank SMS & Alert Sync</h2>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          {/* Sample quick-select presets */}
          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1.5">
              Quick Test: Select Sample Bank SMS
            </label>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_ALERTS.map((sample, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleTextChange(sample.text)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors flex items-center gap-1 text-[11px]"
                >
                  <Copy className="w-3 h-3 text-cyan-400" />
                  {sample.bank}
                </button>
              ))}
            </div>
          </div>

          {/* Paste Input Area */}
          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              Raw Bank SMS or Push Notification Text
            </label>
            <textarea
              rows={3}
              value={inputText}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder="Paste notification text from your banking app or SMS..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-400 text-xs font-mono"
            />
          </div>

          {/* Parsed Result Box */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-400">Extracted Transaction</span>
              <span
                className={`flex items-center gap-1 font-bold text-xs ${
                  parsed.type === 'debit' ? 'text-rose-400' : 'text-emerald-400'
                }`}
              >
                {parsed.type === 'debit' ? (
                  <>
                    <ArrowDownRight className="w-3.5 h-3.5" /> Debit (Expense)
                  </>
                ) : (
                  <>
                    <ArrowUpRight className="w-3.5 h-3.5" /> Credit (Income)
                  </>
                )}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
              <div>
                <span className="text-[10px] text-slate-500 block">Amount</span>
                <span className="text-base font-extrabold text-white font-mono">
                  ${parsed.amount.toFixed(2)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Category</span>
                <span className="text-xs font-medium text-slate-200 capitalize">
                  {parsed.category}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Merchant / Source</span>
                <span className="text-xs font-medium text-slate-200 truncate block">
                  {parsed.description}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Reference</span>
                <span className="text-[11px] font-mono text-slate-400 truncate block">
                  {parsed.referenceNumber}
                </span>
              </div>
            </div>
          </div>

          {/* Confirm Button */}
          <button
            onClick={handleApply}
            disabled={parsed.amount <= 0}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold flex items-center justify-center gap-2 hover:opacity-95 transition-opacity disabled:opacity-40"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            Confirm & Sync to Ledger
          </button>
        </div>
      </div>
    </div>
  );
};
