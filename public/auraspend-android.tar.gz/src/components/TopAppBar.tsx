import React from 'react';
import { RefreshCw, MessageSquareQuote, Smartphone, Monitor, Settings } from 'lucide-react';

interface TopAppBarProps {
  isSyncing: boolean;
  onTriggerBankSync: () => void;
  onOpenSmsParser: () => void;
  isFrameMode: boolean;
  onToggleFrameMode: () => void;
  onOpenConfig: () => void;
  isConfigActive: boolean;
  onOpenInstall: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  isSyncing,
  onTriggerBankSync,
  onOpenSmsParser,
  isFrameMode,
  onToggleFrameMode,
  onOpenConfig,
  isConfigActive,
  onOpenInstall,
}) => {
  return (
    <header className="sticky top-0 z-20 flex items-center justify-between px-4 py-2.5 bg-slate-950/90 backdrop-blur-md border-b border-slate-850">
      {/* Brand title */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center font-bold text-slate-950 text-base shadow-sm">
          ₹
        </div>
        <div>
          <h1 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5 leading-none">
            AuraSpend
            <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
              ₹ INR
            </span>
          </h1>
          <p className="text-[11px] text-slate-400 mt-0.5">Real-time Budget & Bank Sync</p>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center gap-1">
        {/* Install App Button */}
        <button
          onClick={onOpenInstall}
          className="px-2 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-semibold text-xs flex items-center gap-1 transition-colors"
          title="Install Android App"
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span>Install</span>
        </button>
        {/* SMS Parser Button */}
        <button
          onClick={onOpenSmsParser}
          className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/80 active:scale-95 transition-all text-xs flex items-center gap-1"
          title="Parse Bank SMS / Alert"
        >
          <MessageSquareQuote className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline text-xs">SMS</span>
        </button>

        {/* Bank Sync Trigger Button */}
        <button
          onClick={onTriggerBankSync}
          disabled={isSyncing}
          className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium transition-all ${
            isSyncing
              ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
              : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 active:scale-95'
          }`}
          title="Sync Daily Bank Feeds"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-emerald-400' : ''}`} />
          <span className="hidden xs:inline">{isSyncing ? 'Syncing...' : 'Sync'}</span>
        </button>

        {/* Configuration Page Button */}
        <button
          onClick={onOpenConfig}
          className={`p-1.5 rounded-lg transition-colors ${
            isConfigActive
              ? 'bg-emerald-500/20 text-emerald-300'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
          title="Account Configuration & Security"
        >
          <Settings className="w-4 h-4" />
        </button>

        {/* Device Frame View Toggle (hidden on small screens) */}
        <button
          onClick={onToggleFrameMode}
          className="hidden md:flex p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors"
          title={isFrameMode ? 'Switch to Fluid Full View' : 'Switch to Android Device Frame'}
        >
          {isFrameMode ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};

