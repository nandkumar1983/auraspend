import React from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  TrendingDown,
  TrendingUp,
  Landmark,
  CreditCard,
  PiggyBank,
  Wallet,
  AlertCircle,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { BankAccount, CategoryBudget, Transaction } from '../types/expense';
import { formatCurrency, formatDateShort, getTodayString } from '../utils/formatters';
import { TransactionItem } from '../components/TransactionItem';

interface HomeViewProps {
  transactions: Transaction[];
  accounts: BankAccount[];
  budgets: CategoryBudget[];
  onNavigateToTab: (tab: any) => void;
  onOpenAddModal: () => void;
  onDeleteTransaction: (id: string) => void;
  onTriggerBankSync: () => void;
  isSyncing: boolean;
}

const ACCOUNT_ICONS: Record<string, React.FC<{ className?: string }>> = {
  Landmark,
  CreditCard,
  PiggyBank,
  Wallet,
};

export const HomeView: React.FC<HomeViewProps> = ({
  transactions,
  accounts,
  budgets,
  onNavigateToTab,
  onOpenAddModal,
  onDeleteTransaction,
  onTriggerBankSync,
  isSyncing,
}) => {
  const today = getTodayString();
  const currentMonthStr = today.substring(0, 7);

  // Month calculations
  const monthTransactions = transactions.filter((t) => t.date.startsWith(currentMonthStr));
  const monthDebits = monthTransactions
    .filter((t) => t.type === 'debit')
    .reduce((sum, t) => sum + t.amount, 0);
  const monthCredits = monthTransactions
    .filter((t) => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);

  // Today calculations
  const todayTransactions = transactions.filter((t) => t.date === today);
  const todayDebits = todayTransactions
    .filter((t) => t.type === 'debit')
    .reduce((sum, t) => sum + t.amount, 0);
  const todayCredits = todayTransactions
    .filter((t) => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);

  // Budget calculations
  const totalBudgetLimit = budgets.reduce((sum, b) => sum + b.monthlyLimit, 0);
  const budgetSpentPercent = totalBudgetLimit > 0 ? (monthDebits / totalBudgetLimit) * 100 : 0;

  // Day of month calculations for velocity
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const currentDay = now.getDate();
  const daysRemaining = Math.max(1, daysInMonth - currentDay);
  const remainingBudget = Math.max(0, totalBudgetLimit - monthDebits);
  const recommendedDaily = remainingBudget / daysRemaining;

  // Total Liquid Net Worth across accounts
  const liquidBalance = accounts.reduce((sum, acc) => {
    if (acc.type === 'credit') return sum - acc.balance;
    return sum + acc.balance;
  }, 0);

  // Recent transactions (top 5)
  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
      {/* Real-time Spend Velocity & Budget Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-850 border border-slate-800 p-4 shadow-xl">
        {/* Subtle accent glow */}
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium">Total Liquid Balance</span>
          <span className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" /> Reconciled
          </span>
        </div>

        <div className="flex items-baseline justify-between">
          <h2 className="text-2xl font-extrabold text-white font-mono tracking-tight">
            {formatCurrency(liquidBalance)}
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {accounts.length} Accounts Connected
          </span>
        </div>

        {/* Real-time Monthly Budget Tracker Bar */}
        <div className="mt-4 pt-3 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              Monthly Budget Progress
              {budgetSpentPercent > 80 && (
                <span className="text-[10px] text-amber-400 flex items-center gap-0.5">
                  <AlertCircle className="w-3 h-3" />
                  {budgetSpentPercent > 100 ? 'Over Limit' : 'Caution'}
                </span>
              )}
            </span>
            <span className="font-mono text-slate-300 tabular-nums text-xs">
              ₹{monthDebits.toLocaleString('en-IN')} / ₹{totalBudgetLimit.toLocaleString('en-IN')} ({budgetSpentPercent.toFixed(0)}%)
            </span>
          </div>

          <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                budgetSpentPercent > 100
                  ? 'bg-rose-500'
                  : budgetSpentPercent > 80
                  ? 'bg-amber-400'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-400'
              }`}
              style={{ width: `${Math.min(100, budgetSpentPercent)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
            <span>
              Safe daily burn:{' '}
              <strong className="text-emerald-400 font-mono font-bold">
                ₹{recommendedDaily.toLocaleString('en-IN', { maximumFractionDigits: 0 })}/day
              </strong>
            </span>
            <span>{daysRemaining} days left</span>
          </div>
        </div>
      </div>

      {/* Today's Cash Flow Pills */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center shrink-0">
            <ArrowDownRight className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block truncate">Today's Debits</span>
            <span className="text-sm font-bold text-white font-mono tabular-nums">
              {formatCurrency(todayDebits)}
            </span>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
            <ArrowUpRight className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block truncate">Today's Credits</span>
            <span className="text-sm font-bold text-emerald-400 font-mono tabular-nums">
              {formatCurrency(todayCredits)}
            </span>
          </div>
        </div>
      </div>

      {/* Connected Accounts Carousel */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-slate-200">Connected Bank Accounts</h3>
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigateToTab('config')}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-0.5"
            >
              Configure <ChevronRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => onNavigateToTab('sync')}
              className="text-[11px] text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5"
            >
              Sync Feeds <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1">
          {accounts.map((acc) => {
            const Icon = ACCOUNT_ICONS[acc.iconName] || CreditCard;
            return (
              <div
                key={acc.id}
                className="min-w-[170px] max-w-[190px] p-3 rounded-2xl bg-slate-900 border border-slate-800 shrink-0 flex flex-col justify-between space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">{acc.accountNumber}</span>
                </div>
                <div>
                  <h4 className="text-[11px] font-semibold text-slate-200 truncate">{acc.name}</h4>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-sm font-bold text-white font-mono tabular-nums">
                      {formatCurrency(acc.balance)}
                    </span>
                    <span className="text-[9px] text-slate-400 uppercase tracking-wider">
                      {acc.type}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Bank Sync Quick Trigger Banner */}
      <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-800/40 flex items-center justify-between">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-bold text-emerald-300 truncate">Daily Entry Sync</h4>
            <p className="text-[10px] text-slate-400 truncate">Chase, Apple Card & Cloud Feed</p>
          </div>
        </div>
        <button
          onClick={onTriggerBankSync}
          disabled={isSyncing}
          className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 active:scale-95 transition-all shrink-0"
        >
          {isSyncing ? 'Syncing...' : 'Sync Now'}
        </button>
      </div>

      {/* Recent Ledger Entries */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-slate-200">Today & Recent Ledger</h3>
          <button
            onClick={() => onNavigateToTab('transactions')}
            className="text-[11px] text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5"
          >
            All Entries ({transactions.length}) <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-2">
          {recentTransactions.map((tx) => {
            const acc = accounts.find((a) => a.id === tx.accountId);
            return (
              <TransactionItem
                key={tx.id}
                transaction={tx}
                account={acc}
                onDelete={onDeleteTransaction}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};
