import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Download,
  Share2,
  TrendingUp,
  Sparkles,
  Printer,
  ChevronLeft,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  PieChart as PieIcon,
  Store,
} from 'lucide-react';
import { MonthlyReport } from '../types/expense';
import { StorageService } from '../services/storage';
import { CategoryDonutChart } from '../components/CategoryDonutChart';
import { formatCurrency } from '../utils/formatters';

interface ReportsViewProps {
  onExportReport?: () => void;
}

const AVAILABLE_MONTHS = [
  { key: '2026-10', label: 'October 2026' },
  { key: '2026-09', label: 'September 2026' },
  { key: '2026-08', label: 'August 2026' },
];

export const ReportsView: React.FC<ReportsViewProps> = () => {
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-10');

  // Generate automated monthly report
  const report: MonthlyReport = useMemo(() => {
    return StorageService.generateMonthlyReport(selectedMonth);
  }, [selectedMonth]);

  const currentMonthIdx = AVAILABLE_MONTHS.findIndex((m) => m.key === selectedMonth);

  const handlePrevMonth = () => {
    if (currentMonthIdx < AVAILABLE_MONTHS.length - 1) {
      setSelectedMonth(AVAILABLE_MONTHS[currentMonthIdx + 1].key);
    }
  };

  const handleNextMonth = () => {
    if (currentMonthIdx > 0) {
      setSelectedMonth(AVAILABLE_MONTHS[currentMonthIdx - 1].key);
    }
  };

  const donutSlices = report.categoryBreakdown.map((c) => ({
    name: c.categoryName,
    value: c.total,
    color: c.color,
    percentage: c.percentage,
  }));

  const handlePrintOrSave = () => {
    window.print();
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
      {/* Month Selector Bar */}
      <div className="flex items-center justify-between p-2.5 bg-slate-900 border border-slate-800 rounded-2xl">
        <button
          onClick={handlePrevMonth}
          disabled={currentMonthIdx === AVAILABLE_MONTHS.length - 1}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 font-bold text-xs text-white">
          <Calendar className="w-3.5 h-3.5 text-emerald-400" />
          <span>{AVAILABLE_MONTHS[currentMonthIdx]?.label || selectedMonth} Report</span>
        </div>

        <button
          onClick={handleNextMonth}
          disabled={currentMonthIdx === 0}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* High-Level Monthly Cash Flow KPI Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[10px] text-slate-400 block font-medium">Total Debited (Spend)</span>
          <span className="text-base font-extrabold text-white font-mono block">
            {formatCurrency(report.totalDebit)}
          </span>
          <span className="text-[10px] text-slate-500 font-mono">
            Avg: ${report.dailySpendAverage.toFixed(1)}/day
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[10px] text-slate-400 block font-medium">Total Credited (Income)</span>
          <span className="text-base font-extrabold text-emerald-400 font-mono block">
            {formatCurrency(report.totalCredit)}
          </span>
          <span className="text-[10px] text-emerald-400/80 font-mono">
            {report.savingsRate.toFixed(1)}% savings rate
          </span>
        </div>

        <div className="col-span-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">Net Month Savings</span>
          <span
            className={`text-sm font-mono font-bold ${
              report.netSavings >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {report.netSavings >= 0 ? '+' : ''}
            {formatCurrency(report.netSavings)}
          </span>
        </div>
      </div>

      {/* Automated Financial Insights Panel */}
      <div className="p-3.5 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-900/40 space-y-2">
        <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Automated Monthly Insights
        </div>
        <div className="space-y-1.5 text-xs text-slate-300">
          {report.insights.map((insight, idx) => (
            <div key={idx} className="flex items-start gap-2">
              <span className="text-emerald-400 text-xs mt-0.5">•</span>
              <p className="leading-relaxed text-[11px] text-slate-300">{insight}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Category Spend Distribution Donut Chart */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
            <PieIcon className="w-3.5 h-3.5 text-emerald-400" />
            Category Spend Breakdown
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">
            {report.categoryBreakdown.length} Categories
          </span>
        </div>

        <CategoryDonutChart slices={donutSlices} totalSpend={report.totalDebit} />
      </div>

      {/* Detailed Category Breakdown Table */}
      <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 space-y-2.5">
        <h3 className="text-xs font-bold text-white">Category Ledger Analytics</h3>

        <div className="space-y-2">
          {report.categoryBreakdown.map((cat) => (
            <div
              key={cat.categoryId}
              className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: cat.color }}
                />
                <div className="min-w-0">
                  <span className="font-semibold text-slate-200 block truncate">
                    {cat.categoryName}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {cat.count} transactions · {cat.percentage.toFixed(1)}% of total
                  </span>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="font-mono font-bold text-white tabular-nums block">
                  ${cat.total.toFixed(2)}
                </span>
                {cat.budget && (
                  <span
                    className={`text-[10px] font-mono ${
                      cat.isOverBudget ? 'text-rose-400 font-bold' : 'text-slate-400'
                    }`}
                  >
                    {cat.isOverBudget
                      ? `Over $${(cat.total - cat.budget).toFixed(0)}`
                      : `Cap: $${cat.budget}`}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Spending Merchants */}
      {report.topMerchants.length > 0 && (
        <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white">
            <Store className="w-3.5 h-3.5 text-cyan-400" />
            Top Spending Merchants
          </div>

          <div className="space-y-1.5">
            {report.topMerchants.map((m, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2 rounded-xl bg-slate-950/40 text-xs"
              >
                <div className="flex items-center gap-2 truncate">
                  <span className="text-[10px] font-mono text-slate-500 w-4">{idx + 1}.</span>
                  <span className="text-slate-200 font-medium truncate">{m.merchant}</span>
                </div>
                <div className="text-right font-mono shrink-0">
                  <span className="text-white font-bold">${m.total.toFixed(2)}</span>
                  <span className="text-[10px] text-slate-500 block">
                    {m.count} {m.count === 1 ? 'time' : 'times'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Export / Print Report Actions */}
      <div className="pt-1 pb-2">
        <button
          onClick={handlePrintOrSave}
          className="w-full py-2.5 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-slate-200 font-medium text-xs flex items-center justify-center gap-2 transition-colors active:scale-98"
        >
          <Printer className="w-3.5 h-3.5 text-cyan-400" />
          Print / Save PDF Monthly Report
        </button>
      </div>
    </div>
  );
};
