import React, { useState } from 'react';
import {
  Landmark,
  Plus,
  Trash2,
  Edit2,
  Shield,
  ShieldCheck,
  Database,
  Lock,
  Download,
  Smartphone,
  CheckCircle2,
  HardDrive,
  CreditCard,
  PiggyBank,
  Wallet,
  Info,
  Server,
  FileCode2,
} from 'lucide-react';
import { BankAccount } from '../types/expense';
import { formatCurrency } from '../utils/formatters';
import { StorageService } from '../services/storage';

interface AccountConfigViewProps {
  accounts: BankAccount[];
  onAccountsUpdated: (accounts: BankAccount[]) => void;
  isPinEnabled: boolean;
  onTogglePin: (enabled: boolean) => void;
  savedPin: string;
  onUpdatePin: (newPin: string) => void;
  onLockApp: () => void;
}

const ACCOUNT_ICONS: Record<string, React.FC<{ className?: string }>> = {
  Landmark,
  CreditCard,
  PiggyBank,
  Wallet,
};

export const AccountConfigView: React.FC<AccountConfigViewProps> = ({
  accounts,
  onAccountsUpdated,
  isPinEnabled,
  onTogglePin,
  savedPin,
  onUpdatePin,
  onLockApp,
}) => {
  const [isAddingAccount, setIsAddingAccount] = useState(false);
  const [editingAccount, setEditingAccount] = useState<BankAccount | null>(null);

  // New account form state
  const [name, setName] = useState('');
  const [institution, setInstitution] = useState('HDFC Bank');
  const [accountNumber, setAccountNumber] = useState('•••• ');
  const [type, setType] = useState<'checking' | 'savings' | 'credit' | 'cash'>('checking');
  const [balance, setBalance] = useState('10000');
  const [availableLimit, setAvailableLimit] = useState('100000');

  // PIN settings state
  const [newPinInput, setNewPinInput] = useState('');
  const [pinChangeMsg, setPinChangeMsg] = useState<string | null>(null);

  const handleSaveNewAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const newAcc: BankAccount = {
      id: `acc-${Date.now()}`,
      name: name.trim() || `${institution} ${type.toUpperCase()}`,
      institution: institution.trim() || 'Bank',
      accountNumber: accountNumber.trim() || '•••• ' + Math.floor(1000 + Math.random() * 9000),
      type,
      balance: parseFloat(balance) || 0,
      availableLimit: type === 'credit' ? parseFloat(availableLimit) || 0 : undefined,
      lastSyncedAt: 'Just now',
      syncStatus: 'connected',
      color: type === 'credit' ? '#C2410C' : type === 'savings' ? '#0284C7' : '#0A2540',
      iconName: type === 'credit' ? 'CreditCard' : type === 'savings' ? 'PiggyBank' : type === 'cash' ? 'Wallet' : 'Landmark',
      isAutoSyncEnabled: true,
    };

    const updated = [...accounts, newAcc];
    StorageService.saveAccounts(updated);
    onAccountsUpdated(updated);
    setIsAddingAccount(false);

    // Reset
    setName('');
    setBalance('10000');
  };

  const handleUpdateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccount) return;

    const updated = accounts.map((a) => (a.id === editingAccount.id ? editingAccount : a));
    StorageService.saveAccounts(updated);
    onAccountsUpdated(updated);
    setEditingAccount(null);
  };

  const handleDeleteAccount = (id: string) => {
    if (accounts.length <= 1) {
      alert('You must keep at least one active bank account.');
      return;
    }
    const updated = accounts.filter((a) => a.id !== id);
    StorageService.saveAccounts(updated);
    onAccountsUpdated(updated);
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPinInput.length === 4 && /^\d{4}$/.test(newPinInput)) {
      onUpdatePin(newPinInput);
      setNewPinInput('');
      setPinChangeMsg('Security PIN updated successfully.');
      setTimeout(() => setPinChangeMsg(null), 3000);
    } else {
      setPinChangeMsg('PIN must be exactly 4 digits.');
      setTimeout(() => setPinChangeMsg(null), 3000);
    }
  };

  const handleDownloadDbJson = () => {
    const fullDb = {
      app: 'AuraSpend Android App',
      schemaVersion: '2.0.0',
      databaseEngine: 'Local-First WebStorage & IndexedDB Sandbox',
      exportedAt: new Date().toISOString(),
      currency: 'INR (Indian Rupees - ₹)',
      accounts: StorageService.getAccounts(),
      transactions: StorageService.getTransactions(),
      budgets: StorageService.getBudgets(),
      cloudSync: StorageService.getCloudSyncState(),
    };
    const blob = new Blob([JSON.stringify(fullDb, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `auraspend_database_${new Date().toISOString().substring(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
      {/* Configuration Header */}
      <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Landmark className="w-4 h-4 text-emerald-400" />
            Account Configuration
          </h2>
          <p className="text-[11px] text-slate-400">Manage bank accounts, security PIN & storage</p>
        </div>
        <button
          onClick={() => setIsAddingAccount(true)}
          className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-1 hover:bg-emerald-400 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Account
        </button>
      </div>

      {/* Add New Bank Account Inline Modal/Card */}
      {isAddingAccount && (
        <form
          onSubmit={handleSaveNewAccount}
          className="p-4 rounded-3xl bg-slate-900 border border-emerald-500/40 shadow-xl space-y-3 text-xs"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white">Setup New Bank Account</span>
            <button
              type="button"
              onClick={() => setIsAddingAccount(false)}
              className="text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Bank / Institution</label>
              <select
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none"
              >
                <option value="HDFC Bank">HDFC Bank</option>
                <option value="State Bank of India">State Bank of India (SBI)</option>
                <option value="ICICI Bank">ICICI Bank</option>
                <option value="Axis Bank">Axis Bank</option>
                <option value="Kotak Mahindra">Kotak Mahindra</option>
                <option value="Punjab National Bank">Punjab National Bank</option>
                <option value="UPI / Paytm / GPay">UPI / Paytm / GPay</option>
                <option value="Cash Wallet">Cash Wallet</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Account Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none"
              >
                <option value="checking">Salary / Current A/C</option>
                <option value="savings">Savings A/C</option>
                <option value="credit">Credit Card</option>
                <option value="cash">Cash / Digital Wallet</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 block mb-1">Display Account Name</label>
            <input
              type="text"
              placeholder="e.g. HDFC Salary Account, SBI Savings"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">A/C Number or UPI ID</label>
              <input
                type="text"
                placeholder="•••• 4821 or user@upi"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Opening Balance (₹)</label>
              <input
                type="number"
                step="100"
                value={balance}
                onChange={(e) => setBalance(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono font-bold focus:outline-none"
                required
              />
            </div>
          </div>

          {type === 'credit' && (
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Credit Limit (₹)</label>
              <input
                type="number"
                step="1000"
                value={availableLimit}
                onChange={(e) => setAvailableLimit(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
              />
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold flex items-center justify-center gap-1.5 hover:bg-emerald-400 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" />
            Save Bank Account
          </button>
        </form>
      )}

      {/* Existing Configured Accounts List */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-slate-300 px-1">Configured Bank Accounts ({accounts.length})</h3>
        {accounts.map((acc) => {
          const Icon = ACCOUNT_ICONS[acc.iconName] || CreditCard;
          return (
            <div
              key={acc.id}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-slate-850 flex items-center justify-center text-slate-300 shrink-0">
                  <Icon className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 className="font-semibold text-white truncate">{acc.name}</h4>
                  <div className="flex items-center gap-1 text-[10px] text-slate-400">
                    <span>{acc.institution}</span>
                    <span>·</span>
                    <span className="font-mono">{acc.accountNumber}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <div className="text-right">
                  <span className="font-mono font-bold text-emerald-400 block text-xs">
                    {formatCurrency(acc.balance)}
                  </span>
                  <span className="text-[9px] uppercase tracking-wider text-slate-500">
                    {acc.type}
                  </span>
                </div>

                <button
                  onClick={() => setEditingAccount(acc)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title="Edit Account"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => handleDeleteAccount(acc.id)}
                  className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
                  title="Delete Account"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Account Modal */}
      {editingAccount && (
        <form
          onSubmit={handleUpdateAccount}
          className="p-4 rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl space-y-3 text-xs"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white">Edit {editingAccount.name}</span>
            <button
              type="button"
              onClick={() => setEditingAccount(null)}
              className="text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 block mb-1">Account Name</label>
            <input
              type="text"
              value={editingAccount.name}
              onChange={(e) => setEditingAccount({ ...editingAccount, name: e.target.value })}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Current Balance (₹)</label>
              <input
                type="number"
                step="10"
                value={editingAccount.balance}
                onChange={(e) =>
                  setEditingAccount({ ...editingAccount, balance: parseFloat(e.target.value) || 0 })
                }
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono font-bold focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">A/C Number</label>
              <input
                type="text"
                value={editingAccount.accountNumber}
                onChange={(e) =>
                  setEditingAccount({ ...editingAccount, accountNumber: e.target.value })
                }
                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold flex items-center justify-center gap-1.5 hover:bg-cyan-400 transition-colors"
          >
            Update Account Details
          </button>
        </form>
      )}

      {/* Security & App Lock Architecture Section */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-xs">Security & Privacy Architecture</h3>
              <p className="text-[10px] text-slate-400">Zero-knowledge local isolation & PIN lock</p>
            </div>
          </div>

          <button
            onClick={() => onTogglePin(!isPinEnabled)}
            className={`w-11 h-6 rounded-full transition-colors p-0.5 flex items-center ${
              isPinEnabled ? 'bg-emerald-500 justify-end' : 'bg-slate-800 justify-start'
            }`}
          >
            <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
          </button>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-2 text-[11px] text-slate-300">
          <div className="flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block">No Banking Credentials or MPIN Stored:</strong>
              Bank sync uses read-only Open Banking / RBI Account Aggregator (AA) transaction notifications. Your NetBanking password, debit card PIN, or UPI MPIN are never asked, logged, or transmitted.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Lock className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block">Client-Side Encrypted Backups:</strong>
              All cloud snapshots are encrypted before export using client-side AES serialization. No external ad tracking or third-party telemetry.
            </div>
          </div>
        </div>

        {/* PIN Configuration Box */}
        {isPinEnabled && (
          <form onSubmit={handleSavePin} className="pt-2 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Change 4-Digit Security PIN:</span>
              <button
                type="button"
                onClick={onLockApp}
                className="text-[10px] text-amber-400 hover:text-amber-300 font-mono"
              >
                Test Lock Now 🔒
              </button>
            </div>

            <div className="flex gap-2">
              <input
                type="password"
                maxLength={4}
                placeholder="New 4-digit PIN"
                value={newPinInput}
                onChange={(e) => setNewPinInput(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono text-center tracking-widest focus:outline-none"
              />
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors"
              >
                Update PIN
              </button>
            </div>
            {pinChangeMsg && (
              <p className="text-[10px] text-emerald-400 font-medium">{pinChangeMsg}</p>
            )}
          </form>
        )}
      </div>

      {/* Database Details & Storage Transparency */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">Where is the Database Stored?</h3>
            <p className="text-[10px] text-slate-400">Local-First Storage & Cloud Snapshot Engine</p>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-2.5 text-[11px] text-slate-300">
          <div className="flex items-start gap-2">
            <Server className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block">1. Local Device Database (Primary):</strong>
              Your financial records live locally on this device in Android's private sandboxed app partition:
              <code className="text-[10px] font-mono text-cyan-300 block mt-0.5 break-all">
                /data/data/com.auraspend.app/app_webview/Default/Local Storage
              </code>
              All queries, budget tracking calculations, and reports execute 100% locally with zero latency, even when completely offline.
            </div>
          </div>

          <div className="flex items-start gap-2">
            <HardDrive className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block">2. Cloud Storage Database (Replication):</strong>
              When Cloud Sync is enabled, the app serializes an encrypted JSON database snapshot (verified via SHA-256 hash) to your connected Google Cloud / Google Drive storage bucket.
            </div>
          </div>

          <div className="flex items-start gap-2">
            <FileCode2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block">3. Data Portability:</strong>
              You own your data completely. You can download the entire raw database JSON at any time below.
            </div>
          </div>
        </div>

        <button
          onClick={handleDownloadDbJson}
          className="w-full py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          Download Complete Database Snapshot (JSON)
        </button>
      </div>

      {/* How to Install Application Guide */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">How to Install on Android</h3>
            <p className="text-[10px] text-slate-400">PWA WebAPK & Native Android APK steps</p>
          </div>
        </div>

        <div className="space-y-2 text-[11px] text-slate-300">
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <strong className="text-white block">Method A: Instant 1-Tap Android PWA Installation</strong>
            <p className="text-slate-300 leading-relaxed">
              1. Open this application in <strong>Chrome</strong> or <strong>Samsung Internet</strong> on your Android phone.<br />
              2. Tap the browser menu (<strong>⋮</strong> in top-right).<br />
              3. Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.<br />
              4. Android automatically compiles a native <strong>WebAPK</strong> with its own home screen icon, splash screen, and full standalone window.
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <strong className="text-white block">Method B: Generate Native Android APK (.apk)</strong>
            <p className="text-slate-300 leading-relaxed">
              To build a standalone signed Google Play / sideloadable APK:
            </p>
            <div className="p-2 bg-slate-950 rounded-xl font-mono text-[10px] text-cyan-300 space-y-1 overflow-x-auto">
              <p># Using Google Bubblewrap CLI (Official Google Tool):</p>
              <p>npx @bubblewrap/cli init --manifest=https://&lt;your-url&gt;/manifest.json</p>
              <p>npx @bubblewrap/cli build</p>
              <p># Generates app-release-signed.apk ready to install!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
