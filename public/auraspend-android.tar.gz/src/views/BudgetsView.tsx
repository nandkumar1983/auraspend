import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle,
  SlidersHorizontal,
  PlusCircle,
  TrendingUp,
  Info,
} from 'lucide-react';
import { CategoryBudget, Transaction } from '../types/expense';
import { CATEGORIES, formatCurrency, getTodayString } from '../utils/formatters';
import { BudgetEditModal } from '../components/BudgetEditModal';

interface BudgetsViewProps {
  budgets: CategoryBudget[];
  transactions: Transaction[];
  onSaveBudget: (budget: CategoryBudget) => void;
  onOpenAddModal: () => void;
}

export const BudgetsView: React.FC<BudgetsViewProps> = ({
  budgets,
  transactions,
  onSaveBudget,
  onOpenAddModal,
}) => {
  const [editingBudget, setEditingBudget] = useState<CategoryBudget | null>(null);

  const today = getTodayString();
  const currentMonth = today.substring(0, 7);

  // Month stats
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const currentDay = now.getDate();
  const daysRemaining = Math.max(1, daysInMonth - currentDay);

  // Aggregate debits by category for current month
  const categorySpendMap: Record<string, number> = {};
  let totalDebitSpent = 0;

  transactions
    .filter((t) => t.type === 'debit' && t.date.startsWith(currentMonth))
    .forEach((t) => {
      categorySpendMap[t.category] = (categorySpendMap[t.category] || 0) + t.amount;
      totalDebitSpent += t.amount;
    });

  const totalBudgetLimit = budgets.reduce((sum, b) => sum + b.monthlyLimit, 0);
  const totalRemaining = Math.max(0, totalBudgetLimit - totalDebitSpent);
  const overallPercentage = totalBudgetLimit > 0 ? (totalDebitSpent / totalBudgetLimit) * 100 : 0;

  // Projected spend at current velocity
  const dailyPace = totalDebitSpent / currentDay;
  const projectedTotalSpend = dailyPace * daysInMonth;
  const isPacingOverBudget = projectedTotalSpend > totalBudgetLimit;

  // Flag categories that exceeded or are close to limit
  const overBudgetCategories = budgets.filter((b) => {
    const spent = categorySpendMap[b.categoryId] || 0;
    return spent >= b.monthlyLimit;
  });

  const warningCategories = budgets.filter((b) => {
    const spent = categorySpendMap[b.categoryId] || 0;
    return spent >= b.monthlyLimit * b.alertThreshold && spent < b.monthlyLimit;
  });

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
      {/* Month High-Level Pacing Card */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-slate-200">October 2026 Budget Pacing</span>
          <span className="font-mono text-emerald-400">{daysRemaining} days remaining</span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center py-2 bg-slate-950/70 rounded-2xl border border-slate-800/80">
          <div>
            <span className="text-[10px] text-slate-500 block">Total Cap</span>
            <span className="text-sm font-extrabold text-white font-mono">
              ₹{totalBudgetLimit.toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">Spent So Far</span>
            <span className="text-sm font-extrabold text-slate-200 font-mono">
              ₹{totalDebitSpent.toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">Remaining</span>
            <span className="text-sm font-extrabold text-emerald-400 font-mono">
              ₹{totalRemaining.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Big Pacing Progress Bar */}
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
            <span>Overall Spend Utilization</span>
            <span className="font-mono text-slate-200">{overallPercentage.toFixed(1)}%</span>
          </div>
          <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                overallPercentage > 100
                  ? 'bg-rose-500'
                  : overallPercentage > 85
                  ? 'bg-amber-400'
                  : 'bg-emerald-400'
              }`}
              style={{ width: `${Math.min(100, overallPercentage)}%` }}
            />
          </div>
        </div>

        {/* Burn Rate Forecast */}
        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800 text-slate-300">
          <span className="flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
            Projected End-of-Month:
          </span>
          <span
            className={`font-mono font-semibold ${
              isPacingOverBudget ? 'text-amber-400' : 'text-emerald-400'
            }`}
          >
            ₹{projectedTotalSpend.toLocaleString('en-IN', { maximumFractionDigits: 0 })}{' '}
            {isPacingOverBudget ? '(+₹' + (projectedTotalSpend - totalBudgetLimit).toLocaleString('en-IN', { maximumFractionDigits: 0 }) + ' over)' : '(On track)'}
          </span>
        </div>
      </div>

      {/* Real-time Alerts Banner if any category is over/near threshold */}
      {(overBudgetCategories.length > 0 || warningCategories.length > 0) && (
        <div className="p-3 rounded-2xl bg-amber-950/20 border border-amber-800/40 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
            <AlertTriangle className="w-4 h-4" />
            Real-time Budget Alerts
          </div>
          <div className="text-[11px] text-slate-300 space-y-1">
            {overBudgetCategories.map((b) => (
              <p key={b.id} className="text-rose-400 font-medium">
                • {CATEGORIES[b.categoryId]?.name || b.categoryId} exceeded budget cap (₹
                {(categorySpendMap[b.categoryId] || 0).toLocaleString('en-IN')} of ₹{b.monthlyLimit.toLocaleString('en-IN')}).
              </p>
            ))}
            {warningCategories.map((b) => (
              <p key={b.id} className="text-amber-300">
                • {CATEGORIES[b.categoryId]?.name || b.categoryId} has reached{' '}
                {(((categorySpendMap[b.categoryId] || 0) / b.monthlyLimit) * 100).toFixed(0)}% of limit.
              </p>
            ))}
          </div>
        </div>
      )}

      {/* Category Budgets List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-slate-200">Category Budgets</h3>
          <span className="text-[11px] text-slate-400">Tap to edit caps</span>
        </div>

        {budgets.map((budget) => {
          const catDef = CATEGORIES[budget.categoryId] || {
            name: budget.categoryId,
            color: '#64748B',
          };
          const spent = categorySpendMap[budget.categoryId] || 0;
          const percent = budget.monthlyLimit > 0 ? (spent / budget.monthlyLimit) * 100 : 0;
          const remaining = Math.max(0, budget.monthlyLimit - spent);
          const dailyAllowed = remaining / daysRemaining;

          const isOver = percent >= 100;
          const isWarning = percent >= budget.alertThreshold * 100 && !isOver;

          return (
            <div
              key={budget.id}
              onClick={() => setEditingBudget(budget)}
              className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: catDef.color }}
                  />
                  <h4 className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                    {catDef.name}
                  </h4>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-white tabular-nums">
                    ₹{spent.toLocaleString('en-IN', { maximumFractionDigits: 0 })}{' '}
                    <span className="text-slate-500 font-normal">/ ₹{budget.monthlyLimit.toLocaleString('en-IN')}</span>
                  </span>
                  <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300 transition-colors" />
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    isOver ? 'bg-rose-500' : isWarning ? 'bg-amber-400' : 'bg-emerald-400'
                  }`}
                  style={{ width: `${Math.min(100, percent)}%` }}
                />
              </div>

              {/* Footer info */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                <span
                  className={
                    isOver ? 'text-rose-400 font-semibold' : isWarning ? 'text-amber-400' : ''
                  }
                >
                  {isOver
                    ? `Over by ₹${(spent - budget.monthlyLimit).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`
                    : `₹${remaining.toLocaleString('en-IN', { maximumFractionDigits: 0 })} left (₹${dailyAllowed.toLocaleString('en-IN', { maximumFractionDigits: 0 })}/day)`}
                </span>
                <span className="font-mono text-slate-500">{percent.toFixed(0)}%</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal for adjusting budget */}
      <BudgetEditModal
        budget={editingBudget}
        isOpen={!!editingBudget}
        onClose={() => setEditingBudget(null)}
        onSave={onSaveBudget}
      />
    </div>
  );
};
