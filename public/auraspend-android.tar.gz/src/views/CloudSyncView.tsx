import React, { useState } from 'react';
import {
  Cloud,
  CloudLightning,
  RefreshCw,
  ShieldCheck,
  Download,
  Upload,
  HardDrive,
  CheckCircle2,
  Lock,
  Landmark,
  CreditCard,
  PiggyBank,
  Wallet,
  Clock,
  Sparkles,
  Database,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { BankAccount, CloudBackupRecord, CloudSyncState, Transaction } from '../types/expense';
import { StorageService } from '../services/storage';
import { formatCurrency } from '../utils/formatters';

interface CloudSyncViewProps {
  accounts: BankAccount[];
  transactions: Transaction[];
  onTriggerBankSync: () => void;
  isSyncing: boolean;
  onRefreshData: () => void;
  onNavigateToConfig?: () => void;
}

const ACCOUNT_ICONS: Record<string, React.FC<{ className?: string }>> = {
  Landmark,
  CreditCard,
  PiggyBank,
  Wallet,
};

export const CloudSyncView: React.FC<CloudSyncViewProps> = ({
  accounts,
  transactions,
  onTriggerBankSync,
  isSyncing,
  onRefreshData,
  onNavigateToConfig,
}) => {
  const [cloudState, setCloudState] = useState<CloudSyncState>(() =>
    StorageService.getCloudSyncState()
  );
  const [isCloudBackingUp, setIsCloudBackingUp] = useState(false);
  const [backupNotice, setBackupNotice] = useState<string | null>(null);

  const handleManualCloudBackup = async () => {
    setIsCloudBackingUp(true);
    setBackupNotice('Packaging encrypted ledger snapshot for Google Cloud Storage...');

    await new Promise((r) => setTimeout(r, 800));

    const record = StorageService.createCloudBackupSnapshot();
    const updated = StorageService.getCloudSyncState();
    setCloudState(updated);
    setIsCloudBackingUp(false);
    setBackupNotice(`Encrypted snapshot ${record.id} uploaded successfully (${record.sizeKb} KB).`);

    setTimeout(() => setBackupNotice(null), 4000);
  };

  const handleDownloadBackupJson = () => {
    const data = {
      app: 'AuraSpend Android',
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      transactions: StorageService.getTransactions(),
      accounts: StorageService.getAccounts(),
      budgets: StorageService.getBudgets(),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `auraspend_cloud_backup_${new Date().toISOString().substring(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.transactions && parsed.accounts) {
          StorageService.saveTransactions(parsed.transactions);
          StorageService.saveAccounts(parsed.accounts);
          if (parsed.budgets) StorageService.saveBudgets(parsed.budgets);
          onRefreshData();
          setBackupNotice(`Restored ${parsed.transactions.length} transactions from cloud file.`);
          setTimeout(() => setBackupNotice(null), 4000);
        }
      } catch (err) {
        setBackupNotice('Invalid backup JSON format.');
        setTimeout(() => setBackupNotice(null), 4000);
      }
    };
    reader.readAsText(file);
  };

  const toggleAutoSync = () => {
    const updated: CloudSyncState = {
      ...cloudState,
      autoSyncEnabled: !cloudState.autoSyncEnabled,
    };
    StorageService.saveCloudSyncState(updated);
    setCloudState(updated);
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
      {/* Cloud Status Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center">
              <Cloud className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-xs flex items-center gap-1.5">
                Google Cloud & Drive Sync
                <span className="text-[10px] text-emerald-400 font-mono">Active</span>
              </h3>
              <p className="text-[10px] text-slate-400">
                End-to-end encrypted ledger replication
              </p>
            </div>
          </div>

          <button
            onClick={handleManualCloudBackup}
            disabled={isCloudBackingUp}
            className="px-3 py-1.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 transition-colors flex items-center gap-1 shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isCloudBackingUp ? 'animate-spin' : ''}`} />
            {isCloudBackingUp ? 'Backing up...' : 'Backup Now'}
          </button>
        </div>

        {backupNotice && (
          <div className="p-2 rounded-xl bg-cyan-950/40 border border-cyan-800/40 text-[11px] text-cyan-300 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{backupNotice}</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-slate-800/80">
          <div>
            <span className="text-[10px] text-slate-500 block">Last Cloud Sync</span>
            <span className="font-mono text-slate-300 text-xs">{cloudState.lastSyncedAt || 'Today'}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">Cloud Snapshot Size</span>
            <span className="font-mono text-slate-300 text-xs">{cloudState.storageUsedKb} KB</span>
          </div>
        </div>

        {/* Auto Sync Toggle */}
        <div className="flex items-center justify-between pt-1 text-xs">
          <span className="text-slate-300">Automated Daily Cloud Sync</span>
          <button
            onClick={toggleAutoSync}
            className={`w-11 h-6 rounded-full transition-colors p-0.5 flex items-center ${
              cloudState.autoSyncEnabled ? 'bg-emerald-500 justify-end' : 'bg-slate-800 justify-start'
            }`}
          >
            <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
          </button>
        </div>
      </div>

      {/* Daily Bank Sync Engine Section */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Landmark className="w-3.5 h-3.5 text-emerald-400" />
              Connected Bank Feeds (Open Banking)
            </h3>
            <p className="text-[10px] text-slate-400">Daily credit & debit entries auto-clearing</p>
          </div>
          <div className="flex items-center gap-2">
            {onNavigateToConfig && (
              <button
                onClick={onNavigateToConfig}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white font-medium text-xs hover:bg-slate-750 transition-colors"
              >
                Configure
              </button>
            )}
            <button
              onClick={onTriggerBankSync}
              disabled={isSyncing}
              className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors flex items-center gap-1"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing ? 'Syncing...' : 'Sync All Feeds'}
            </button>
          </div>
        </div>

        <div className="space-y-2">
          {accounts.map((acc) => {
            const Icon = ACCOUNT_ICONS[acc.iconName] || CreditCard;
            return (
              <div
                key={acc.id}
                className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-slate-850 flex items-center justify-center text-slate-300 shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-semibold text-slate-200 truncate">{acc.name}</h4>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                      <span>{acc.institution}</span>
                      <span>·</span>
                      <span className="font-mono">{acc.accountNumber}</span>
                      <span>·</span>
                      <span className="text-emerald-400">{acc.lastSyncedAt}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="font-mono font-bold text-white block">
                    {formatCurrency(acc.balance)}
                  </span>
                  <span className="text-[10px] text-emerald-400 flex items-center justify-end gap-1 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    Synced
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cloud Snapshot History & Restore */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-4 space-y-3">
        <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
          <Database className="w-3.5 h-3.5 text-cyan-400" />
          Cloud Snapshot History & Export
        </h3>

        <div className="space-y-1.5">
          {cloudState.backupHistory.slice(0, 4).map((bk) => (
            <div
              key={bk.id}
              className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-850 flex items-center justify-between text-[11px]"
            >
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-slate-200 font-mono block">{bk.timestamp}</span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {bk.recordCount} entries · {bk.sizeKb} KB · {bk.hash}
                  </span>
                </div>
              </div>
              <span className="text-[10px] text-slate-400 font-medium">Verified</span>
            </div>
          ))}
        </div>

        {/* Action Buttons for Download and Restore */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
          <button
            onClick={handleDownloadBackupJson}
            className="py-2.5 px-2 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            Download JSON
          </button>

          <label className="py-2.5 px-2 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>Restore Backup</span>
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
